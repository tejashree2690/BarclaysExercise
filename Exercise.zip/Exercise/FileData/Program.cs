﻿using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {
        public static void Main(string[] args)
        {

            Console.WriteLine("Start");
            Prototype.CallFileVersionTask1("-v","filepath");
            string val;
            Console.WriteLine("Please select Version or Size: ");
                
            val = Console.ReadLine();
            Prototype.CallFileVersionTask2(val, "filepath");

            Console.ReadKey();

        }
    }


    public static class Prototype 
    {
        public static void CallFileVersionTask1(string pVersion,string pfilepath)
        {
            if(pVersion=="-v")
            {  
                 FileDetails objFileDetails= new FileDetails();
                Console.WriteLine(objFileDetails.Version(pfilepath));
            }

        }


        public static void CallFileVersionTask2(string pVersionOrSize, string pfilepath)
        {
            //string[] vVersionValid = { "-v", "--v", "/v", "--version" };

            //foreach (string x in vVersionValid)
            //{
            //    if (pVersionOrSize.Contains(x))
            //    {
            //        FileDetails objFileDetails = new FileDetails();
            //        Console.WriteLine(objFileDetails.Version(pfilepath));
            //    }
            //}

            if (pVersionOrSize == "-v" || pVersionOrSize == "--v" || pVersionOrSize == "/v" || pVersionOrSize == "--version")
            {
                FileDetails objFileDetails = new FileDetails();
                Console.WriteLine(objFileDetails.Version(pfilepath));
            }
            else if (pVersionOrSize == "-s" || pVersionOrSize == "--s" || pVersionOrSize == "/s" || pVersionOrSize == "--size")
            {
                FileDetails objFileDetails = new FileDetails();
                Console.WriteLine(objFileDetails.Size(pfilepath));
            }
            else 
            {
                Console.WriteLine("Please select values for Version as  -v,--v,/v,--version and for Size -s,--s,/s,--size");
            }

        }

    }

}
