﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            FileData.Prototype.CallFileVersionTask1("-v", "filepath");

        }

        [TestMethod]
        public void TestMethod2()
        {
            FileData.Prototype.CallFileVersionTask1("-v1", "filepath");

        }

        [TestMethod]
        public void TestMethod6()
        {
            FileData.Prototype.CallFileVersionTask2("-v", "filepath");

        }


        [TestMethod]
        public void TestMethod3()
        {
            FileData.Prototype.CallFileVersionTask2("-v1", "filepath");

        }


        [TestMethod]
        public void TestMethod4()
        {
            FileData.Prototype.CallFileVersionTask2("-s", "filepath");

        }

        [TestMethod]
        public void TestMethod5()
        {
            FileData.Prototype.CallFileVersionTask2("-s1", "filepath");

        }
    }
}
